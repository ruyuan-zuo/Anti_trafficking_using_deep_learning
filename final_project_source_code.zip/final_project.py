#!/usr/bin/env python
# coding: utf-8

# # Part One
# This part is intended to demostrate that there can be a neural network constructed with the input data

# In[1]:


import numpy as np
import pandas as pd
import tensorflow as tf
import random
from tensorflow import keras
from tensorflow.keras import layers


# In[2]:


#  import data 
data_rs = pd.read_csv('The Global Dataset 14 Apr 2020.csv',low_memory=False)
# data_rs = pd.DataFrame(data_rs).to_numpy()

#  select columns
selected_columns = data_rs[["gender","ageBroad","RecruiterRelationship", "CountryOfExploitation","isSexualExploit"]]

new_df = selected_columns.copy()


temp=new_df.drop(new_df.index[new_df['isSexualExploit'] == -99]) #drop non information layers
new_df=temp.drop(temp.index[temp['ageBroad'] == '-99']) #drop non-information layers


temp=new_df.drop(new_df.index[new_df['RecruiterRelationship'] == '-99']) #drop non information layers
new_df=temp.drop(temp.index[temp['RecruiterRelationship'] == -99]) #drop non information layers

new_df_=new_df.drop(new_df.index[new_df['CountryOfExploitation'] == '-99']) #drop non-information layers

cleanup_nums = {"gender":     {"Female": 2, "Male": 1},
                "ageBroad": {"0--8": 1, "9--17": 2, "18--20": 3, "21--23": 4,
                                  "24--26": 5, "27--29": 6, "30--38":7, "39--47":8, "48+":9 },
                "CountryOfExploitation":     {"US":1,"RU":1, "ID":2,"HT":3, 
                                                "JO":4,    
                                                "UG":5,    
                                                "KZ":6,      
                                                "LB":7,      
                                                "PL":8,      
                                                "SA":9,      
                                                "AE":10,     
                                                "BD":11,     
                                                "KH":12,     
                                                "CN":13,     
                                                "PH":14,      
                                                "LY":15,     
                                                "BY":16,      
                                                "AF":17,     
                                                "HK":18,      
                                                "EG":19,     
                                                "MY":20},

                "RecruiterRelationship":     {"Not Specified":4,
                                "Other":4 ,
                                "Intimate Partner":1 ,
                                "Family/Relative":2 ,
                                "Friend/Acquaintance":3 ,
                                "Friend/Acquaintance; Other":3 ,
                                "Family/Relative; Intimate Partner":3 ,
                                "Intimate Partner; Other":1 ,
                                "Friend/Acquaintance; Intimate Partner":1 ,
                                "Not Specified; Other":4 ,
                                "Family/Relative; Other":2 ,
                                "Family/Relative; Friend/Acquaintance":2 ,
                                "Family/Relative; Not Specified":2 ,
                                "Intimate Partner; Not Specified": 1,
                                "Friend/Acquaintance; Intimate Partner; Other":3 ,
                                "Family/Relative; Friend/Acquaintance; Other":2 ,
                                "Friend/Acquaintance; Intimate Partner; Not Specified":3 ,
                                "Family/Relative; Intimate Partner; Other": 2,
                                "Friend/Acquaintance; Not Specified; Other":3 ,
                                "Friend/Acquaintance; Not Specified":3}      }
                # gender, ages 
new_df_.replace(cleanup_nums, inplace=True) #replaces 

new_df_["CountryOfExploitation"].value_counts() #find the ranges of ages 


# In[3]:


new_df_["RecruiterRelationship"].value_counts() #find the ranges of ages 


# In[4]:



new_df = new_df_#displaying the head values
new_df


# In[5]:


new_df_["isSexualExploit"].value_counts() #find the ranges of ages 


# In[6]:


new_df.count() #display counts table
new_df['isSexualExploit'].value_counts() #display counts sex


# In[7]:



is_SexualExploit =  new_df['isSexualExploit']==1 #15140
is_not_SexualExploit =  new_df['isSexualExploit']==0 #7794

datab_is_sex = new_df[is_SexualExploit] # 15140
datab_is_not_sex = new_df[is_not_SexualExploit] #7794

datab_is_sex_  = datab_is_sex.sample(frac=1).reset_index(drop=True)

datab_is_sex_ = datab_is_sex_.drop(datab_is_sex_.index[:-2263 ], axis=0)
temp = datab_is_sex[:2263]
datab_is_sex_


# In[8]:



t_11= pd.concat([datab_is_sex_, datab_is_not_sex], ignore_index=True)
#new_df = t_11
t_11


# In[9]:


#t_11.plot.bar(stacked=True);


# In[10]:


# spliting the data to train and test sets 
train=new_df.sample(frac=0.8,random_state=200) #random state is a seed value
test=new_df.drop(train.index)


# In[11]:


# get train x and train y with the label alues 
train_x = train.drop('isSexualExploit',axis=1).to_numpy()
train_y = train.drop(train.columns[[0,1,2,3]], axis=1).to_numpy()


# In[12]:


# get train x and train y with the label alues 
test_x = test.drop('isSexualExploit',axis=1).to_numpy()
test_y = test.drop(test.columns[[0, 1,2,3]], axis=1).to_numpy()


# In[13]:


test_y


# In[14]:


test_x


# In[15]:


# Reserve 1000 samples for validation
x_val = train_x[-1000:]
y_val = train_y[-1000:]
x_train = train_x[:-1000]
y_train = train_y[:-1000]


# In[16]:


inputs = keras.Input(shape=(4,), name="int") #input = 2 
x = layers.Dense(32, activation="sigmoid", name="dense_1")(inputs)
x = layers.Dense(16, activation="sigmoid", name="dense_2")(x)
x = layers.Dropout(0.25, noise_shape=None, seed=None)(x)

x = layers.Dense(32, activation="relu", name="dense_3")(x)
x = layers.Dropout(0.25, noise_shape=None, seed=None)(x)

x = layers.Dense(64, activation="sigmoid", name="dense_4")(x)

outputs = layers.Dense(2, activation="softmax", name="predictions")(x)

model = keras.Model(inputs=inputs, outputs=outputs)
model.summary()


# In[17]:


model.compile(
    optimizer=keras.optimizers.RMSprop(),  
     loss=keras.losses.SparseCategoricalCrossentropy(),
     metrics=[keras.metrics.SparseCategoricalAccuracy()],
)


# In[18]:


# just to demostrate this net work can work
# need more work on selecting the parameters 
# because now this has very large loss val

model.fit(
    x_train,
    y_train,
    batch_size=64,
    epochs=100,   
    validation_data=(x_val, y_val),
)


# # Part Two 
# This part is intended to demostrate the second part with text understanding 

# In[19]:


import nltk
import random
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.layers import Dense, Flatten, Embedding, LSTM, GRU
from tensorflow.keras.models import Sequential
from nltk import CFG
from nltk.corpus import nps_chat
from nltk.parse.generate import generate, demo_grammar


# In[20]:



grammar = CFG.fromstring(demo_grammar)

chatroom = nps_chat.posts('10-19-20s_706posts.xml')
data = []
for p in nps_chat.xml_posts():
    data.append({"class":p.get("class"), "txt": p.text})
df = pd.DataFrame.from_dict(data)
k =df[df['class'] == 'Statement'].copy()
len_k = len(k)
k.head()


# In[21]:


#  select columns
selected_columns = k[["txt"]]

df1 = selected_columns.copy()
m = np.zeros((len_k))

df2 =  pd.DataFrame(np.array(m),
                   columns=['label'])
df1
df2


# In[22]:


def generate_sample(grammar, prod, txt):        
    if prod in grammar._lhs_index: 
        derivations = grammar._lhs_index[prod]            
        derivation = random.choice(derivations)            
        for d in derivation._rhs:            
            generate_sample(grammar, d, txt)
    elif prod in grammar._rhs_index:
        # terminal
        txt.append(str(prod))
        


# In[23]:


# generating the second half of the data with CFG
from random import choice
grammar = nltk.CFG.fromstring("""
            S -> NP VP
            PP -> P NP
            NP -> Det N | Det N PP | 'I'
            VP -> V NP | VP PP
            Det -> 'an' | 'my'|'young'
            N -> 'girl ' | 'women'| 'chick'| 'China'
            V -> 'shot' | 'want' |'service'|'sex'
            P -> 'in'
            """)

txt = [] 
text_array = []


df1_ = pd.DataFrame([],
                   columns=['txt'])
for j in range(len_k ):
    txt = [] 
    generate_sample(grammar, grammar.start(), txt)
    txt = ' '.join(word for word in txt)
    df1_ = df1_.append({'txt': txt}, ignore_index=True)
k = np.ones(len(df1_))

df2_ =  pd.DataFrame(np.array(k),
                   columns=['label'])

df1_


# In[24]:


## again this is the concate step with labels ones and zeros, the df texts one and two 

df1 = pd.concat([df1, df1_], axis=0)
df2 = pd.concat([df2, df2_], axis=0)

#reset the indexes for concat purpose
df1.reset_index(inplace=True, drop=True)

df2.reset_index(inplace=True, drop=True)
df2
final = pd.concat([df1, df2], axis=1)
final


# In[25]:


tokenizer = Tokenizer(num_words=2500, lower=True,split=' ')
tokenizer.fit_on_texts(final['txt'].values)
X = tokenizer.texts_to_sequences(final['txt'].values)
X = pad_sequences(X)
X =  pd.DataFrame(np.array(X))
Y = (final['label']).values

Y =  pd.DataFrame(np.array(Y),columns=['label'])
X


# In[26]:


np.shape(X)


# In[27]:


nnn = pd.concat([X, Y], axis=1)
# np.shape(nnn)
nnn[1]


# In[28]:


train=nnn.sample(frac=0.8,random_state=200) #random state is a seed value

test=nnn.drop(train.index)
train


# In[29]:


[a,v] = np.shape(train)
#v-2
train_x = train.drop('label',axis=1).to_numpy()
train_y = train.drop(train.iloc[:, 0:(v-1)], axis=1).to_numpy()
[a,v] = np.shape(test)
#v-2
test_x = test.drop('label',axis=1).to_numpy()
test_y = test.drop(test.iloc[:, 0:(v-1)], axis=1).to_numpy()

# Reserve 1000 samples for validation
x_val = train_x[-1000:]
y_val = train_y[-1000:]
x_train = train_x[:-1000]
y_train = train_y[:-1000]


# In[30]:


x_val


# In[31]:


y_val


# In[32]:



embed_dim =128
lstm_out = 200
print("check size of input ",v-1)
inputs = keras.Input(shape=(v-1,), name="int")
x = layers.Embedding(2500, embed_dim )(inputs)
x = layers.LSTM(lstm_out)(x)

outputs = layers.Dense(2, activation="softmax", name="predictions")(x)

model = keras.Model(inputs=inputs, outputs=outputs)
model.summary()


# In[33]:


model.compile(
    optimizer=keras.optimizers.RMSprop(),  
     loss=keras.losses.SparseCategoricalCrossentropy(),
     metrics=[keras.metrics.SparseCategoricalAccuracy()],
)


# In[34]:


model.fit(x_train, y_train, batch_size =32,epochs=10,   
    validation_data=(x_val, y_val),)


# # Reference:
# 
# 
# [1] https://towardsdatascience.com/understanding-lstm-and-its-quick-implementation-in-keras-for-sentiment-analysis-af410fd85b47
# 
# [2] http://www.nltk.org/book_1ed/ch05.html
# 
# [3] https://stackoverflow.com/questions/15009656/how-to-use-nltk-to-generate-sentences-from-an-induced-grammar

# In[ ]:




